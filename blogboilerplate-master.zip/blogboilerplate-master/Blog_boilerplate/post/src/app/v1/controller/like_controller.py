from fastapi import Depends, status, Request
from fastapi_utils.cbv import cbv
from fastapi_utils.inferring_router import InferringRouter
from app.v1.schema import CreateLikeRequest, CreateLikeResponse
from app.v1.service import LikeCommandService
from uuid import UUID
from core.utils.jwt_bearer import HasPermission

router = InferringRouter()


@cbv(router=router)
class LikeController:
    like_command_service: LikeCommandService = Depends(LikeCommandService)

    @router.post(
        "/likeUnlikePost",
        status_code=status.HTTP_200_OK,
        name="Like-Unlike Post",
    )
    async def like_unlike_post(self, post_id: UUID, current_user_id: UUID = Depends(HasPermission())):
        return await self.like_command_service.create_like_unlike(post_id=post_id, user_id=current_user_id)

    @router.post(
        "/likeUnlikeComment",
        status_code=status.HTTP_200_OK,
        name="Like-Unlike Comment",
    )
    async def like_unlike_comment(self, comment_id: UUID, post_id: UUID, current_user_id: UUID = Depends(HasPermission())):
        return await self.like_command_service.create_like_unlike_comment(comment_id=comment_id, post_id=post_id, user_id=current_user_id)

    @router.post(
        "/likeUnlikeReplyComment",
        status_code=status.HTTP_200_OK,
        name="Like-Unlike Comment Reply"
    )
    async def like_unlike_comment_reply(self, reply_id: UUID, comment_id: UUID, post_id: UUID, current_user_id: UUID = Depends(HasPermission())):
        return await self.like_command_service.create_like_unlike_comment_reply(reply_id=reply_id, comment_id=comment_id, post_id=post_id, user_id=current_user_id)
