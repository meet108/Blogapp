import uuid
from typing import List
from fastapi import Depends, status, Request
from fastapi_utils.cbv import cbv
from fastapi_utils.inferring_router import InferringRouter
from app.v1.schema import CreateCommentRequest, CreateCommentResponse, CreateCommentReplyResponse
from app.v1.service import CommentCommandService
from uuid import UUID
from core.utils.jwt_bearer import HasPermission

router = InferringRouter()


@cbv(router=router)
class CommentController:
    comment_command_service: CommentCommandService = Depends(CommentCommandService)

    @router.post(
        "/addComment",
        status_code=status.HTTP_200_OK,
        response_model=CreateCommentResponse,
        name="Add Comment",
    )
    async def add_comment(self, request: CreateCommentRequest, post_id: UUID,
                          current_user_id: UUID = Depends(HasPermission())):
        return await self.comment_command_service.create_comment(post_id=post_id, user_id=current_user_id,
                                                                 **request.dict())

    @router.get(
        "/get_comment_reply",
        status_code=status.HTTP_200_OK,
        # response_model=CreateCommentReplyResponse,
        name="Get comment reply"
    )
    async def get_comment_reply(self, comment_id: UUID) :
        return await self.comment_command_service.show_comment_reply(comment_id=comment_id)

    @router.delete(
        "/deleteComment",
        status_code=status.HTTP_200_OK,
        name="Delete Comment",
        description="",
        operation_id="delete_comment"
    )
    async def delete_comment(self, comment_id: UUID, post_id: UUID, current_user_id: UUID = Depends(HasPermission())):
        return await self.comment_command_service.delete_comment(comment_id=comment_id, post_id=post_id,
                                                                 user_id=current_user_id)

    @router.put(
        "/updateComment",
        status_code=status.HTTP_200_OK,
        response_model=CreateCommentResponse,
        response_description="",
        name="Update a Comment",
        description="",
        operation_id="update_comment")
    async def update_comment(self, request: CreateCommentRequest, comment_id: UUID, post_id: UUID,
                             current_user_id: UUID = Depends(HasPermission())):
        return await self.comment_command_service.update_comment(comment_id=comment_id, user_id=current_user_id,
                                                                 post_id=post_id, request=request)

    @router.post(
        "/replyonComment",
        name="Reply On a comment",
        description="",
        operation_id="reply_comment")
    async def reply_comment(self, request: CreateCommentRequest, comment_id: UUID, post_id: UUID,
                            current_user_id: UUID = Depends(HasPermission())):
        return await self.comment_command_service.reply_comment(comment_id=comment_id, post_id=post_id,
                                                                user_id=current_user_id, request=request)
