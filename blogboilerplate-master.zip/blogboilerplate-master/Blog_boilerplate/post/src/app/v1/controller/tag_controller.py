import uuid
from app.v1.schema.request import CreateTagRequest
from app.v1.schema.response import CreateTagResponse
from app.v1.service.tag_command import TagCommandService
from fastapi import Depends, status
from fastapi.responses import JSONResponse
from fastapi_utils.cbv import cbv
from fastapi_utils.inferring_router import InferringRouter
from pydantic.schema import UUID

router = InferringRouter()


@cbv(router=router)
class TagController:
    tag_command_services: TagCommandService = Depends(TagCommandService, use_cache=True)

    @router.post("/add tag",
                 status_code=status.HTTP_200_OK,
                 response_model=CreateTagResponse,
                 name="Create Tag",
                 operation_id="create_tag"
                 )
    async def create_tag(self, request: CreateTagRequest):
        return await self.tag_command_services.create_tag(**request.dict())

