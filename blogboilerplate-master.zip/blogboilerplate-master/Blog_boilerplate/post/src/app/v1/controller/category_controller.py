import uuid
from app.v1.schema.request import CreateCategoryRequest
from app.v1.schema.response import CreateCategoryResponse
from app.v1.service.category_command import CategoryCommandService
from fastapi import Depends, status
from fastapi.responses import JSONResponse
from fastapi_utils.cbv import cbv
from fastapi_utils.inferring_router import InferringRouter
from pydantic.schema import UUID

router = InferringRouter()


@cbv(router=router)
class CategoryController:
    category_command_services: CategoryCommandService = Depends(CategoryCommandService, use_cache=True)

    @router.post("/add category",
                 status_code=status.HTTP_200_OK,
                 response_model=CreateCategoryResponse,
                 name="Create Category",
                 operation_id="create_category"
                 )
    async def create_category(self, request: CreateCategoryRequest):
        return await self.category_command_services.create_category(**request.dict())

