import uuid

from app.v1.models import UserModel, CodeModel
from app.v1.schema.request import CreateUserRequestSchema, LoginUserRequestSchema, ForgotPassword, ResetPassword, \
    ChangePassword
from app.v1.schema.response import CreateUserResponse, LoginUserResponse
from app.v1.service.user_command import UserCommandService
from fastapi import Depends, status
from fastapi.responses import JSONResponse
from fastapi_utils.cbv import cbv
from fastapi_utils.inferring_router import InferringRouter
from pydantic.schema import UUID
from core.utils.jwt_bearer import HasPermission

router = InferringRouter()


@cbv(router=router)
class UserController:
    user_command_services: UserCommandService = Depends(UserCommandService, use_cache=True)

    @router.post("/signup",
                 status_code=status.HTTP_200_OK,
                 response_model=CreateUserResponse,
                 name="Create User",
                 operation_id="create_user"
                 )
    async def create_user(self, request: CreateUserRequestSchema):
        return await self.user_command_services.create_user(**request.dict())

    @router.post("/login",
                 status_code=status.HTTP_200_OK,
                 response_model=LoginUserResponse,
                 name="Login User",
                 operation_id="login_user"
                 )
    async def login_user(self, request: LoginUserRequestSchema) -> LoginUserResponse:
        return await self.user_command_services.login_user(**request.dict())

    @router.post("/forgot-password")
    async def forgot_password(self, request: ForgotPassword):
        return await self.user_command_services.forgot_password(**request.dict())

    @router.post("/reset-password")
    async def reset_password(self, request: ResetPassword):
        return await self.user_command_services.reset_password(**request.dict())

    @router.post("/change-password")
    async def change_password(self,
                              request: ChangePassword,
                              current_user_id: UUID = Depends(HasPermission())):
        return await self.user_command_services.change_password(user_id=current_user_id, **request.dict())

    # @router.get(
    #     "/",
    #     status_code=status.HTTP_200_OK,
    #     response_description="",
    #     name="Get all User",
    #     description="",
    #     operation_id="get_all_user",
    # )
    # async def get_all_users(self):
    #     return await self.user_command_services.show_user()

    @router.delete(
        "/{user_id}",
        status_code=status.HTTP_200_OK,
        response_model=None,
        response_description="",
        name="Delete a User",
        description="",
        operation_id="delete_user",
    )
    async def delete_user(self, current_user_id: UUID = Depends(HasPermission())):
        await self.user_command_services.delete_user(user_id=current_user_id)
        return JSONResponse(status_code=200, content={"status": "success"})

    @router.put("/{user_id}",
                status_code=status.HTTP_200_OK,
                response_model=CreateUserResponse,
                response_description="",
                name="Update a User",
                description="",
                operation_id="update_user",
                )
    async def update_user(self, request: CreateUserRequestSchema,  current_user_id: UUID = Depends(HasPermission())):
        user_id = uuid.UUID(str(current_user_id))
        return await self.user_command_services.update_user(user_id=current_user_id, request=request)
        # return JSONResponse(status_code=200, content={"status": "success"})
