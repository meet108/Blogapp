from app.v1.controller.user_controller import UserController
from app.v1.controller.user_controller import router as user_router
from app.v1.controller.post_controller import PostController
from app.v1.controller.post_controller import router as post_router
from app.v1.controller.category_controller import router as category_router
from app.v1.controller.category_controller import CategoryController
from app.v1.controller.tag_controller import TagController
from app.v1.controller.tag_controller import router as tag_router
from app.v1.controller.comment_controller import CommentController
from app.v1.controller.comment_controller import router as comment_router
from app.v1.controller.like_controller import LikeController
from app.v1.controller.like_controller import router as like_router
__all__ = [
    "UserController",
    "user_router",
    "PostController",
    "post_router",
    "CategoryController",
    "category_router",
    "TagController",
    "tag_router",
    "CommentController",
    "comment_router",
    "LikeController",
    "like_router"
]