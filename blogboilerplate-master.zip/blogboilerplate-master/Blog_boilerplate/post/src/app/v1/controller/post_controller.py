import uuid
from fastapi import Depends, status, Header
from fastapi.responses import JSONResponse
from fastapi_utils.cbv import cbv
from fastapi_utils.inferring_router import InferringRouter
from pydantic.schema import UUID
from typing import NoReturn, Union
from app.v1.models import PostModel, UserModel
from app.v1.schema import CreatePostRequest, CreatePostResponse, CreatePostCommentResponse, CreatePostIdResponse
from app.v1.service import PostCommandService
# from core.utils.jwt_token import JWToken, decode, encode
# from core.utils.jwt_bearer import JWTBearer
from core.utils.jwt_bearer import HasPermission
from typing import List, Optional

router = InferringRouter()


@cbv(router=router)
class PostController:
    post_command_services: PostCommandService = Depends(PostCommandService, use_cache=True)

    @router.post(
        "/post",
        status_code=status.HTTP_200_OK,
        response_model=CreatePostResponse,
        response_description="",
        name="Create Post",
        description="hello",
        operation_id="create_post",
    )
    async def create_post(
            self,
            request: CreatePostRequest,
            category_id: UUID,
            current_user_id: UUID = Depends(HasPermission()),
    ) -> Union[PostModel, NoReturn]:
        return await self.post_command_services.create_post(
            user_id=current_user_id, category_id=category_id, tags=request.tags, title=request.title,
            content=request.content
        )

    @router.get(
        "/",
        status_code=status.HTTP_200_OK,
        response_model=List[CreatePostResponse],
        response_description="",
        name="Get All Post",
        description="hello",
        operation_id="get_all_post",
    )
    async def get_all_posts(self):
        return await self.post_command_services.show_post()

    @router.get("/get_Post_by_id/",
                response_model=CreatePostIdResponse,
                status_code=status.HTTP_200_OK,
                name="Show Post by Id"
                )
    async def get_post_by_id(self, post_id: UUID):
        return await self.post_command_services.show_post_by_id(post_id=post_id)

    @router.get("/get_comment",
                status_code=status.HTTP_200_OK,
                name="Show Comment"
                )
    async def get_comment(self, post_id: UUID):
        return await self.post_command_services.show_comment(post_id=post_id)

    @router.delete(
        "/{post_id}",
        status_code=status.HTTP_200_OK,
        response_model=None,
        response_description="",
        name="Delete a Post",
        description="",
        operation_id="delete_post",
    )
    async def delete_post(self, post_id: UUID, current_user_id: UUID = Depends(HasPermission())):
        return await self.post_command_services.delete_post(post_id=post_id, user_id=current_user_id)

    @router.put("/update/{post_id}",
                status_code=status.HTTP_200_OK,
                response_model=CreatePostResponse,
                response_description="",
                name="Update a Post",
                description="",
                operation_id="update_post",
                )
    async def update_post(self, request: CreatePostRequest,
                          post_id: UUID,
                          category_id: UUID,
                          current_user_id: UUID = Depends(HasPermission())):
        return await self.post_command_services.update_post(post_id=post_id, category_id=category_id,
                                                            user_id=current_user_id, request=request)

    @router.get(
        "/get_Post_by_Tags/{tag_name}",
        status_code=status.HTTP_200_OK,
        name="Show Post by Tag"
    )
    async def show_post_by_tag(self, tag_name: str):
        return await self.post_command_services.show_post_by_tag(tag_name)

    @router.get(
        "/getPostbyCategory/{category_name}",
        status_code=status.HTTP_200_OK,
        name="Show Post by Category"
    )
    async def show_post_by_category(self, category_name: str):
        return await self.post_command_services.show_post_by_category(category_name)

