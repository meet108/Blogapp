from uuid import UUID
from pydantic import Field
from fastapi_utils.api_model import APIModel
from pydantic.schema import Optional, datetime
from typing import List

class CreateLikeResponse(APIModel):
    like_id: UUID
    user_id: UUID
    post_id: UUID

class CreateCommentResponse(APIModel):
    comment_id: UUID
    post_id: UUID
    user_id: UUID
    comment: str
    reply_id: Optional[UUID]
    comment_published: datetime

class CreateCategoryResponse(APIModel):
    category_id: UUID
    name: str


class CreateTagResponse(APIModel):
    tag_id: UUID
    name: str
    class Config:
        orm_mode = True

class CreatePostResponse(APIModel):
    post_id: UUID
    user_id: UUID
    title: str = Field(max_length=50)
    content: str
    like_count: Optional[int]
    comment_count: int
    published: datetime

    class Config:
        orm_mode = True


class CreateUserResponse(APIModel):
    user_id: UUID
    first_name: str
    last_name: str
    email: str
    password: str


class LoginUserResponse(APIModel):
    access_token: str

class CreatePostCommentResponse(APIModel):
    comment: str

class CreatePostIdResponse(APIModel):
    user_id: UUID
    title: str = Field(max_length=50)
    content: str
    like_count: Optional[int]
    comment_count: int
    published: datetime


class CreateCommentReplyResponse(APIModel):
    comment_reply = str


