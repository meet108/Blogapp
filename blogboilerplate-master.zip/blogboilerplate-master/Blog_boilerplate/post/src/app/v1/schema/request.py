from enum import Enum
from pydantic import BaseModel, Field, validator
from pydantic import EmailStr, validate_email
from pydantic.schema import Optional, UUID
import re
from typing import List
from app.v1.types import SupportedFormats
from enum import Enum
regex = re.compile('[@_!#$%^&*()<>?/\|}{~:]')
rege = re.compile("(?=.*[0-9])")
reg = re.compile("(?=.*[!@#$%^&*()])(?=.*[0-9])(?=.*[A-Z])(?=.*[a-z])")


class CreateUserRequestSchema(BaseModel):
    first_name: str
    last_name: str
    email: EmailStr
    password: str

    @validator('first_name')
    def check_first_name(cls, v):
        if (regex.search(v) != None or re.search(r"\s", v) or rege.search(v)!=None):
            raise ValueError("First name not allowed space, number & special character")
        return v

    @validator('last_name')
    def check_last_name(cls, v):
        if (regex.search(v) != None or re.search(r"\s", v) or rege.search(v)!=None):
            raise ValueError("Last name not allowed space, number & special character")
        return v

    @validator('password')
    def check_password(cls, v):
        if (re.search(r"\s", v) or len(v)<8 or reg.search(v)== None):
            raise ValueError(
                "Password not allowed space, atleast one special character , one number required, length 8 required.")
        return v


class LoginUserRequestSchema(BaseModel):
    email: EmailStr
    password: str


class CreatePostRequest(BaseModel):
    title: str
    content: str
    tags: List[str]


class CreateCategoryRequest(BaseModel):
    name: str

class CreateTagRequest(BaseModel):
    name: str

class ForgotPassword(BaseModel):
    email: EmailStr

class ResetPassword(BaseModel):
    email: EmailStr
    otp_code: int
    new_password: str
    confirm_password: str

    @validator('new_password')
    def check_new_password(cls, v):
        if (re.search(r"\s", v) or len(v) < 8 or reg.search(v) == None):
            raise ValueError(
                "Password not allowed space, atleast one special character , one number required, length 8 required.")
        return v

class ChangePassword(BaseModel):
    old_password: str
    change_password: str
    confirm_password: str

    @validator('change_password')
    def check_change_password(cls, v):
        if (re.search(r"\s", v) or len(v) < 8 or reg.search(v) == None):
            raise ValueError(
                "Password not allowed space, atleast one special character , one number required, length 8 required.")
        return v


class CreateCommentRequest(BaseModel):
    comment:str
    reply_id:  Optional[UUID] = None

class CreateLikeRequest(BaseModel):
    post_id:UUID

