from enum import Enum
class LikeType(str, Enum):
    """
    Enum class for like type
    """

    like = "like"
    unlike = "unlike"
