# from core import NotFoundException, UnauthorizedException
#
#
# class UserNotFound(NotFoundException):
#     """
#     Custom exception for post not found
#     """
#
#     message = "Post doesn't exist"
#
#
# class CanNotDeleteUser(UnauthorizedException):
#     """
#     Custom exception for can not delete post
#     """
#
#     message = "Can't delete post that belongs to different user"
