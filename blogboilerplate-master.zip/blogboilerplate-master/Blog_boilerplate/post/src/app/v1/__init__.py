from fastapi import APIRouter
from core.db.session import Base
from app.v1.controller import user_router, post_router, tag_router, category_router, comment_router, like_router
v1_router = APIRouter()
v1_router.include_router(user_router, prefix="/user", tags=["User"])
v1_router.include_router(post_router, prefix="/post", tags=["Post"])
v1_router.include_router(like_router, prefix="/like", tags=["Like"])
v1_router.include_router(comment_router, prefix="/comment", tags=["Comment"])
v1_router.include_router(category_router, prefix="/category", tags=["Category"])
v1_router.include_router(tag_router, prefix="/tag", tags=["Tag"])
__all__ = ["v1_router", "Base"]