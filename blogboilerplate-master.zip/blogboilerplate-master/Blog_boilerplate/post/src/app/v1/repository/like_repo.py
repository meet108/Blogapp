from typing import List
from uuid import UUID

from fastapi import Depends
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.v1.models import LikeModel, PostModel, LikeCommentModel, LikeReplyModel
from app.v1.schema import CreateLikeRequest
from core import db_session


class LikeRepo:
    def __init__(self, db: AsyncSession = Depends(db_session)):
        self.session = db

    async def save(self, like: LikeModel) -> LikeModel:
        self.session.add(like)
        return like

    async def delete(self, like: LikeModel):
        await self.session.delete(like)
        return None

    async def like_unlike(self, user_id: UUID, post_id: UUID):
        check = await self.session.execute(
            select(LikeModel).where(LikeModel.post_id == post_id and LikeModel.user_id == user_id))
        return check.scalars().first()

    async def like_unlike_comment(self, post_id: UUID, comment_id: UUID):
        check = await self.session.execute(
            select(LikeCommentModel).where(LikeCommentModel.post_id == post_id,  LikeCommentModel.comment_id == comment_id))
        return check.scalars().first()

    async def like_unlike_comment_reply(self, post_id: UUID, comment_id: UUID, reply_id: UUID):
        check = await self.session.execute(
            select(LikeReplyModel).where(LikeReplyModel.post_id == post_id,
                                           LikeReplyModel.comment_id == comment_id, LikeReplyModel.reply_id == reply_id))
        return check.scalars().first()
