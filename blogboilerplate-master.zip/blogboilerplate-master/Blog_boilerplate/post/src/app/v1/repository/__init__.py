from app.v1.repository.user_repo import UserRepo
from app.v1.repository.code_repo import CodeRepo
from app.v1.repository.post_repo import PostRepo
from app.v1.repository.category_repo import CategoryRepo
from app.v1.repository.tag_repo import TagRepo
from app.v1.repository.comment_repo import CommentRepo
from app.v1.repository.like_repo import LikeRepo
__all__ = ["UserRepo", "PostRepo", "CategoryRepo", "TagRepo", "CodeRepo", "CommentRepo", "LikeRepo"]