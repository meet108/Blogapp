from sqlalchemy.ext.asyncio import AsyncSession
from app.v1.models.user_model import CodeModel
from core import db_session
from app.v1.schema import ForgotPassword
from fastapi import Depends
from pydantic.schema import UUID
from sqlalchemy import select
from typing import Optional, List


class CodeRepo:
    def __init__(self, db: AsyncSession = Depends(db_session)):
        self.session = db

    async def save(self, code: CodeModel) -> CodeModel:
        self.session.add(code)
        self.session.refresh(code)
        return code

    async def get_with_email(self, email: str) -> Optional[CodeModel]:
        query = await self.session.execute(
            select(CodeModel).where(CodeModel.email == email)
        )
        return query.scalars().first()

    async def verify_otp(self, otp_code: int) -> Optional[CodeModel]:
        query = await self.session.execute(
            select(CodeModel).where(CodeModel.otp_code == otp_code)
        )
        return query.scalars().first()

    async def update_otp(self, code: CodeModel):
        self.session.add(code)
        await self.session.commit()
        await self.session.refresh(code)
        return code

    async def verify_email_otp(self, email: str, otp_code: int):
        query = await self.session.execute(
            select(CodeModel).where(CodeModel.email == email, CodeModel.otp_code == otp_code)
        )
        return query.scalars().first()