from typing import List
from uuid import UUID

from fastapi import Depends
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.v1.models import CommentModel, PostModel
from app.v1.schema import CreateCommentRequest
from core import db_session


class CommentRepo:
    def __init__(self, db: AsyncSession = Depends(db_session)):
        self.session = db


    async def save(self, comment: CommentModel) -> CommentModel:
        self.session.add(comment)
        await self.session.commit()
        return comment

    async def delete(self, comment: CommentModel):
        await self.session.delete(comment)
        return None

    async def get_comment_post_id(self, post_id: UUID, comment_id: UUID) -> CommentModel:
        result = await self.session.execute(select(CommentModel).where(CommentModel.comment_id == comment_id, CommentModel.post_id == post_id))
        return result.scalars().first()

    async def get_comment_id(self, comment_id: UUID) -> CommentModel:
        result = await self.session.execute(select(CommentModel).where(CommentModel.comment_id == comment_id))
        return result.scalars().first()

    async def get_by_comment_name(self, comment_name: str) -> CommentModel:
        query = await self.session.execute(select(CommentModel).where(CommentModel.comment == comment_name))
        return query.scalars().first()



    async def get_comment_post_reply_id(self, post_id: UUID, comment_id: UUID, reply_id: UUID) -> CommentModel:
        result = await self.session.execute(
            select(CommentModel).where(CommentModel.comment_id == comment_id, CommentModel.post_id == post_id, CommentModel.reply_id == reply_id))
        return result.scalars().first()
