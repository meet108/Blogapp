from sqlalchemy.ext.asyncio import AsyncSession
from app.v1.models.user_model import UserModel, CodeModel
from core import db_session
from app.v1.schema import CreateUserRequestSchema
from fastapi import Depends
from pydantic.schema import UUID
from sqlalchemy import select
from typing import Optional, List


class UserRepo:
    def __init__(self, db: AsyncSession = Depends(db_session)):
        self.session = db

    async def save(self, user: UserModel) -> UserModel:
        self.session.add(user)
        return user

    async def get_with_email(self, email: str) -> Optional[UserModel]:
        query = await self.session.execute(
            select(UserModel).where(UserModel.email == email)
        )
        return query.scalars().first()

    async def get_all(self) -> List[UserModel]:
        query = await self.session.execute(select(UserModel))
        return query.scalars().all()

    async def delete(self, user: UserModel):
        await self.session.delete(user)
        return None

    async def get_by_userid(self, user_id: UUID) -> UserModel:
        query = await self.session.execute(select(UserModel).where(UserModel.user_id == user_id))
        return query.scalars().first()

    async def update_password(self, user: UserModel):
        self.session.add(user)
        await self.session.commit()
        await self.session.refresh(user)
        return "Password Update Successfully"
