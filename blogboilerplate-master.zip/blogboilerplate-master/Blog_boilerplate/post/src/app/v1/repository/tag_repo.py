from sqlalchemy.ext.asyncio import AsyncSession
from app.v1.models.tag_model import TagModel
from core import db_session
from app.v1.schema import CreateTagRequest
from fastapi import Depends
from pydantic.schema import UUID
from sqlalchemy import select
from typing import Optional, List


class TagRepo:
    def __init__(self, db: AsyncSession = Depends(db_session)):
        self.session = db

    async def save(self, tag: TagModel) -> TagModel:
        self.session.add(tag)
        return tag




    async def get_by_tagid(self, tag_id: UUID) -> TagModel:
        query = await self.session.execute(select(TagModel).where(TagModel.tag_id == tag_id))
        return query.scalars().first()

    async def get_by_tagname(self, tag_name: str) -> TagModel:
        query = await self.session.execute(select(TagModel).where(TagModel.name == tag_name))
        return query.scalars().first()
