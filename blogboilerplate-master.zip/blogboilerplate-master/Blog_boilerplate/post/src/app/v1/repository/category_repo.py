from sqlalchemy.ext.asyncio import AsyncSession
from app.v1.models.category_model import CategoryModel
from core import db_session
from app.v1.schema import CreateCategoryRequest
from fastapi import Depends
from pydantic.schema import UUID
from sqlalchemy import select
from typing import Optional, List


class CategoryRepo:
    def __init__(self, db: AsyncSession = Depends(db_session)):
        self.session = db

    async def save(self, category: CategoryModel) -> CategoryModel:
        self.session.add(category)
        return category

    async def get_by_categoryid(self, category_id: UUID) -> CategoryModel:
        query = await self.session.execute(select(CategoryModel).where(CategoryModel.category_id == category_id))
        return query.scalars().first()

    async def get_by_category_name(self, category_name: str) -> CategoryModel:
        query = await self.session.execute(select(CategoryModel).where(CategoryModel.name == category_name))
        return query.scalars().first()