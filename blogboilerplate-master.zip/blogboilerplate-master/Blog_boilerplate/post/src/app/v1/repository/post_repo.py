from typing import List, Optional

from fastapi import Depends
from pydantic.schema import UUID
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.v1.models import PostModel, TagModel, CategoryModel
from core import db_session


class PostRepo:
    def __init__(self, db: AsyncSession = Depends(db_session)):
        self.session = db

    async def save(self, post: PostModel, tags: Optional[List[TagModel]]) -> PostModel:

        self.session.add(post)

        return post

    async def get_all(self):
        query = await self.session.execute(select(PostModel))
        return query.scalars().all()

    async def delete(self, user: PostModel):
        await self.session.delete(user)
        return None

    async def get_by_userid(self, user_id: UUID) -> PostModel:
        query = await self.session.execute(select(PostModel).where(PostModel.user_id == user_id))
        return query.scalars().first()

    async def get_by_postid(self, post_id: UUID, user_id: UUID) -> PostModel:
        query = await self.session.execute(select(PostModel).where(PostModel.post_id == post_id, PostModel.user_id == user_id))
        return query.scalars().first()

    async def get_by_deletepostid(self, post_id: UUID) -> PostModel:
        query = await self.session.execute(select(PostModel).where(PostModel.post_id == post_id))
        return query.scalars().first()

    async def get_by_post_id(self, post_id: UUID) -> PostModel:
        query = await self.session.execute(select(PostModel).where(PostModel.post_id == post_id))
        return query.scalars().first()

    async def get_by_post_category(self, category: str) -> CategoryModel:
        query = await self.session.execute(select(CategoryModel).where(CategoryModel.name == category))
        return query.scalars().first()

    async def get_by_post_tag(self, tag: str) -> TagModel:
        query = await self.session.execute(select(TagModel).where(TagModel.name == tag))
        return query.scalars().first()





