import uuid
import datetime
from sqlalchemy import Column, Integer, String, inspect, Table, ForeignKey, DateTime
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from core import Base
from app.v1.models.post_model import post_tag

class TagModel(Base):
    __tablename__ = "tag"
    tag_id = Column(UUID(as_uuid=True), primary_key=True)
    name = Column(String, nullable=False)

    post = relationship("PostModel", secondary=post_tag, back_populates="tags", lazy="selectin")

    def __init__(self,
                 tag_id: uuid,
                 name: str):
        self.tag_id = tag_id
        self.name = name

    @classmethod
    def create(cls, name: str):
        tag_id = uuid.uuid4()
        return cls(
            tag_id=tag_id,
            name=name)
