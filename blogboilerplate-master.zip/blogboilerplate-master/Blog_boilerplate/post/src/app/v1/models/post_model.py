import uuid
import datetime
from sqlalchemy import Column, Integer, String, inspect, Table, ForeignKey, DateTime
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from typing import List
from core import Base

# Many To Many Relationship
post_tag = Table("post_tag",
                 Base.metadata,
                 Column("post_id", ForeignKey("post.post_id"), primary_key=True),
                 Column("tag_id", ForeignKey("tag.tag_id"), primary_key=True),
                 )



class PostModel(Base):
    __tablename__ = "post"
    post_id = Column(UUID(as_uuid=True), primary_key=True)
    title = Column(String, nullable=False)
    content = Column(String, nullable=False)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.user_id"), nullable=False)
    category_id = Column(UUID(as_uuid=True), ForeignKey("category.category_id"), nullable=True)
    like_count = Column(Integer, default=0, nullable=False)
    comment_count = Column(Integer, default=0, nullable=False)
    published = Column(DateTime, nullable=False, default=datetime.datetime.utcnow())

    like = relationship(
        "LikeModel", lazy="selectin", cascade="all, delete"
    )

    comment = relationship(
        "CommentModel", lazy="selectin", cascade="all, delete"
    )

    user = relationship("UserModel", back_populates="post", cascade="all, delete",lazy="selectin")

    tags = relationship(
        "TagModel", secondary=post_tag, back_populates="post", lazy="selectin", cascade="all, delete"
    )

    categories = relationship(
        "CategoryModel", back_populates="post", lazy="selectin", cascade="all, delete")

    def __init__(self,
                 post_id: uuid,
                 title: str,
                 content: str,
                 user_id: uuid,
                 category_id: uuid,
                 like_count: int,
                 comment_count: int,
                 published: DateTime
                 ):
        self.post_id = post_id
        self.title = title
        self.content = content
        self.user_id = user_id
        self.category_id = category_id
        self.like_count = like_count
        self.comment_count = comment_count
        self.published = published

    @classmethod
    def create(cls, user_id: UUID, category_id: UUID, title: str, content: str):
        post_id = uuid.uuid4()
        like_count = 0
        comment_count = 0
        published = datetime.datetime.utcnow()
        return cls(post_id=post_id,
                   user_id=user_id,
                   category_id=category_id,
                   title=title,
                   content=content,
                   like_count=like_count,
                   comment_count=comment_count,
                   published=published)
