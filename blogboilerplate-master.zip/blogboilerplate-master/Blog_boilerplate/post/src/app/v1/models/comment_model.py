from sqlalchemy import Column, String, DateTime, ForeignKey, Integer
from sqlalchemy.dialects.postgresql import UUID
import datetime
from core import Base
from sqlalchemy.orm import relationship
import uuid


class CommentModel(Base):
    __tablename__ = "comment"

    comment_id = Column(UUID(as_uuid=True), primary_key=True)
    comment = Column(String)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.user_id"))
    post_id = Column(UUID(as_uuid=True), ForeignKey("post.post_id"))
    like_count = Column(Integer, default=0, nullable=False, server_default="0")
    comment_published = Column(DateTime, default=datetime.datetime.utcnow())
    comment_reply = Column(String)
    reply_id = Column(UUID(as_uuid=True), nullable=True)
    reply_count = Column(Integer, default=0, nullable=False, server_default="0")
    reply_like_count = Column(Integer, default=0, nullable=False, server_default="0")
    like_comment = relationship("LikeCommentModel", back_populates="comment", lazy="selectin")
    like_comment_reply = relationship("LikeReplyModel", back_populates="comment", lazy="selectin")
    # def __init__(
    #         self,
    #         comment_id: uuid,
    #         comment: str,
    #         user_id: uuid,
    #         post_id: uuid,
    #         comment_published: DateTime
    # ):
    #     self.comment_id = comment_id
    #     self.comment = comment
    #     self.user_id = user_id
    #     self.post_id = post_id
    #     self.comment_published = comment_published
    #
    # @classmethod
    # def create(cls, post_id: uuid, user_id: uuid, comment: str):
    #     comment_id: uuid.uuid4()
    #     return cls(
    #         comment_id=comment_id,
    #         comment=comment,
    #         user_id=user_id,
    #         post_id=post_id
    #     )
