from sqlalchemy import Column, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from core import Base
import uuid
from sqlalchemy.orm import relationship

class LikeModel(Base):
    __tablename__="like"

    like_id = Column(UUID(as_uuid=True), primary_key=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.user_id"))
    post_id = Column(UUID(as_uuid=True), ForeignKey("post.post_id"))

    post = relationship("PostModel", back_populates="like", lazy="selectin")
    def __init__(self, like_id: uuid, user_id: uuid, post_id: uuid):
        self.like_id = like_id
        self.user_id = user_id
        self.post_id = post_id

    @classmethod
    def create(cls, user_id: uuid, post_id: uuid):
        like_id = uuid.uuid4()
        return cls(like_id=like_id, user_id=user_id, post_id=post_id)

class LikeCommentModel(Base):
    __tablename__ = "like_comment"
    like_id = Column(UUID(as_uuid=True), primary_key=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.user_id"))
    post_id = Column(UUID(as_uuid=True), ForeignKey("post.post_id"))
    comment_id = Column(UUID(as_uuid=True), ForeignKey("comment.comment_id"))

    comment = relationship("CommentModel", back_populates="like_comment", lazy="selectin")

    def __init__(self, like_id: uuid, user_id: uuid, post_id: uuid, comment_id: uuid):
        self.like_id = like_id
        self.user_id = user_id
        self.post_id = post_id
        self.comment_id = comment_id

    @classmethod
    def create(cls, user_id: uuid, post_id: uuid, comment_id: uuid):
        like_id = uuid.uuid4()
        return cls(like_id=like_id, user_id=user_id, post_id=post_id, comment_id=comment_id)

class LikeReplyModel(Base):
    __tablename__ = "like_comment_reply"
    like_id = Column(UUID(as_uuid=True), primary_key=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.user_id"))
    post_id = Column(UUID(as_uuid=True), ForeignKey("post.post_id"))
    comment_id = Column(UUID(as_uuid=True), ForeignKey("comment.comment_id"))
    reply_id = Column(UUID(as_uuid=True))
    comment = relationship("CommentModel", back_populates="like_comment_reply", lazy="selectin")

    def __init__(self, like_id: uuid, user_id: uuid, post_id: uuid, comment_id: uuid, reply_id: uuid):
        self.like_id = like_id
        self.user_id = user_id
        self.post_id = post_id
        self.comment_id = comment_id
        self.reply_id = reply_id

    @classmethod
    def create(cls, user_id: uuid, post_id: uuid, comment_id: uuid, reply_id: uuid):
        like_id = uuid.uuid4()
        return cls(like_id=like_id, user_id=user_id, post_id=post_id, comment_id=comment_id, reply_id=reply_id)