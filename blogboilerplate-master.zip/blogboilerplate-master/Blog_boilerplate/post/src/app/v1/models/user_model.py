import uuid
from typing import Optional, List
from core import Base
from sqlalchemy import Column, String, Integer, DateTime, Boolean
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from core.utils.password import Hasher
from app.v1.schema import CreateUserResponse
import datetime
from random import randint
class UserModel(Base):
    __tablename__ = "users"
    user_id = Column(UUID(as_uuid=True), primary_key=True)
    email = Column(String(70))
    first_name = Column(String(70), nullable=True)
    last_name = Column(String(70), nullable=True)
    password = Column(String)

    post = relationship("PostModel", back_populates="user", lazy='selectin', cascade="all, delete")

    def __init__(self,
                 user_id: uuid,
                 email: str,
                 first_name: str,
                 last_name: str,
                 password: str,
                 ):
        self.user_id = user_id
        self.email = email
        self.first_name = first_name
        self.last_name = last_name
        self.password = Hasher.get_password_hash(password)

    @classmethod
    def create(cls,
               email: str,
               password: str,
               first_name: str,
               last_name: str,
               ):
        user_id = uuid.uuid4()
        return cls(
            user_id=user_id,
            email=email,
            first_name=first_name,
            last_name=last_name,
            password=password,
        )


class CodeModel(Base):
    __tablename__ = "codes"
    code_id = Column(UUID(as_uuid=True), primary_key=True)
    email = Column(String(70))
    otp_code = Column(Integer)
    expired = Column(DateTime)

    def __int__(self,
                code_id: uuid,
                email: str,
                otp_code: int,
                expired: DateTime):
        self.code_id = code_id
        self.email = email
        self.otp_code = otp_code
        self.expired = expired

    @classmethod
    def create_code(cls,
                    email: str,
                    ):
        otp_code= randint(10000, 100000)
        expired = datetime.datetime.now() + datetime.timedelta(minutes=5)
        code_id = uuid.uuid4()
        return cls(
            code_id=code_id,
            email=email,
            otp_code=otp_code,
            expired=expired
        )
