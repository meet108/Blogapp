import uuid
import datetime
from sqlalchemy import Column, Integer, String, inspect, Table, ForeignKey, DateTime
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from core import Base

class CategoryModel(Base):
    __tablename__ = "category"
    category_id = Column(UUID(as_uuid=True), primary_key=True)
    name = Column(String, nullable=False)

    post = relationship("PostModel", back_populates="categories", lazy="selectin")
    def __init__(self,
                 category_id: uuid,
                 name: str):
        self.category_id = category_id
        self.name = name

    @classmethod
    def create(cls, name: str):
        category_id = uuid.uuid4()
        return cls(
            category_id=category_id,
            name=name)
