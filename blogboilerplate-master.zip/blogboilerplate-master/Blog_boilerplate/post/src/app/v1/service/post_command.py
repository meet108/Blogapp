from fastapi import Depends, HTTPException
from httpx import AsyncClient
from app.v1.models import PostModel, TagModel, UserModel, CategoryModel, CommentModel
from app.v1.schema import CreatePostRequest, CreateUserRequestSchema
from app.v1.repository import PostRepo, TagRepo, CategoryRepo, UserRepo, CommentRepo
from pydantic.schema import UUID
from typing import List, Optional

client = AsyncClient()


class PostCommandService:
    def __init__(
            self,
            user_repo: UserRepo = Depends(UserRepo),
            post_repo: PostRepo = Depends(PostRepo),
            tag_repo: TagRepo = Depends(TagRepo),
            category_repo: CategoryRepo = Depends(CategoryRepo),
            comment_repo: CommentRepo = Depends(CommentRepo)
    ):
        self.post_repo = post_repo
        self.tag_repo = tag_repo
        self.user_repo = user_repo
        self.category_repo = category_repo
        self.comment_repo = comment_repo

    async def create_post(self,
                          user_id: UUID,
                          category_id: UUID,
                          title: str,
                          content: str,
                          tags: List[str],
                          ):
        check_category = await self.category_repo.get_by_categoryid(category_id=category_id)
        if not check_category:
            raise HTTPException(status_code=409, detail="Category Not Found")
        tag_list = list()
        for tag in tags:
            query = await self.tag_repo.get_by_tagname(tag_name=tag)
            if not query:
                new_tag = TagModel.create(name=tag)
                await self.tag_repo.save(tag=new_tag)
                await self.tag_repo.session.commit()
                tag_list.append(new_tag)
            else:
                tag_list.append(query)
        post = PostModel.create(user_id=user_id, category_id=category_id, title=title, content=content)
        for i in tag_list:
            post.tags.append(i)
        post = await self.post_repo.save(post=post, tags=tag_list)
        print(post)
        await self.post_repo.session.commit()
        return post

    async def show_post(self):
        result = await self.post_repo.get_all()
        return result
    async def show_post_by_id(self, post_id: UUID):
        post = await self.post_repo.get_by_post_id(post_id=post_id)
        if not post:
            raise HTTPException(status_code=409, detail="Post Not Found")
        return post

    async def show_comment(self, post_id: UUID):
        post = await self.post_repo.get_by_post_id(post_id=post_id)
        if not post:
            raise HTTPException(status_code=409, detail="Post Not Found")
        if not post.comment:
            return {"message": "Comment Not Found"}
        return post.comment

    async def show_post_by_tag(self, tag: str):
        tag = await self.post_repo.get_by_post_tag(tag=tag)
        if not tag:
            raise HTTPException(status_code=409, detail="Tag Not Found")
        return tag.post

    async def show_post_by_category(self, category: str):
        category = await self.post_repo.get_by_post_category(category=category)
        if not category:
            raise HTTPException(status_code=409, detail="Category Not Found")
        return category.post

    async def delete_post(self, post_id: UUID, user_id: UUID):
        post = await self.post_repo.get_by_post_id(post_id=post_id)
        if not post:
            raise HTTPException(status_code=409, detail="Post Not Found")
        elif post:
            if user_id != post.user_id:
                raise HTTPException(status_code=409, detail="Can Not Delete")
            else:
                await self.post_repo.session.delete(post)
        await self.post_repo.session.commit()
        return {"message": "successfully deleted"}

    async def update_post(self, post_id: UUID, category_id: UUID, user_id: UUID, request: CreatePostRequest):
        check_category = await self.category_repo.get_by_categoryid(category_id=category_id)
        if not check_category:
            raise HTTPException(status_code=409, detail="Category Not Found")
        post = await self.post_repo.get_by_postid(post_id=post_id, user_id=user_id)
        if not post:
            raise HTTPException(status_code=409, detail="Post Not Found")
        tags = request.tags
        tag_list = []
        for tag in tags:
            query = await self.tag_repo.get_by_tagname(tag_name=tag)
            if not query:
                new_tag = TagModel.create(name=tag)
                await self.tag_repo.save(tag=new_tag)
                await self.tag_repo.session.commit()
                tag_list.append(new_tag)
            else:
                tag_list.append(query)
        post.title = request.title
        post.content = request.content
        post.category_id = check_category.category_id
        for i in tag_list:
            post.tags.append(i)
        post.tags = tag_list
        self.post_repo.session.add(post, tag_list)
        await self.post_repo.session.commit()
        await self.post_repo.session.refresh(post)
        return post
