from fastapi import Depends, HTTPException
from app.v1.repository import LikeRepo, PostRepo, CommentRepo, UserRepo
from app.v1.models import LikeModel, PostModel, CommentModel, LikeCommentModel, UserModel, LikeReplyModel
import uuid
from uuid import UUID
from app.v1.schema import CreateLikeRequest, CreateCommentRequest


class LikeCommandService:
    def __init__(
            self,
            like_repo: LikeRepo = Depends(LikeRepo),
            post_repo: PostRepo = Depends(PostRepo),
            comment_repo: CommentRepo = Depends(CommentRepo),
            user_repo: UserRepo = Depends(UserRepo)
    ):
        self.like_repo = like_repo
        self.post_repo = post_repo
        self.comment_repo = comment_repo
        self.user_repo = user_repo
    async def create_like_unlike(self,
                                 user_id: UUID,
                                 post_id: UUID):
        post = await self.post_repo.get_by_post_id(post_id=post_id)
        if not post:
            raise HTTPException(status_code=409, detail="Post Not Found")
        like_unlike= await self.like_repo.like_unlike(user_id=user_id, post_id=post_id)
        if not like_unlike:
            create_like = LikeModel.create(user_id=user_id, post_id=post_id)
            await self.like_repo.save(like=create_like)
            post.like_count = post.like_count + 1
            await self.like_repo.session.commit()
            return {"message": "Post Liked"}
        else:
            post.like_count = post.like_count - 1
            await self.like_repo.delete(like_unlike)
            await self.like_repo.session.commit()
            return {"message": "Post Unliked"}

    async def create_like_unlike_comment(self, user_id: UUID, post_id: UUID, comment_id: UUID):
        user = await self.user_repo.get_by_userid(user_id=user_id)
        if not user:
            raise HTTPException(status_code=409, detail="User Not Found")
        post = await self.post_repo.get_by_post_id(post_id=post_id)
        if not post:
            raise HTTPException(status_code=409, detail="Post Not Found")
        comment = await self.comment_repo.get_comment_id(comment_id=comment_id)
        if not comment:
            raise HTTPException(status_code=409, detail="Comment Not Found")
        like_unlike_comment = await self.like_repo.like_unlike_comment(post_id=post_id, comment_id=comment_id)
        if not like_unlike_comment:
            create_like_comment = LikeCommentModel.create(user_id=user_id, post_id=post_id, comment_id=comment_id)
            await self.like_repo.save(like=create_like_comment)
            comment.like_count = comment.like_count + 1
            await self.like_repo.session.commit()
            return {"message": "Comment Liked"}
        else:
            comment.like_count = comment.like_count - 1
            await self.like_repo.delete(like_unlike_comment)
            await self.like_repo.session.commit()
            return {"message": "Comment Unliked"}

    async def create_like_unlike_comment_reply(self, reply_id: UUID, user_id: UUID, post_id: UUID, comment_id: UUID):
        user = await self.user_repo.get_by_userid(user_id=user_id)
        if not user:
            raise HTTPException(status_code=409, detail="User Not Found")
        post = await self.post_repo.get_by_post_id(post_id=post_id)
        if not post:
            raise HTTPException(status_code=409, detail="Post Not Found")
        comment = await self.comment_repo.get_comment_id(comment_id=comment_id)
        if not comment:
            raise HTTPException(status_code=409, detail="Comment Not Found")
        like_unlike_comment = await self.like_repo.like_unlike_comment_reply(post_id=post_id, comment_id=comment_id, reply_id=reply_id)
        if not like_unlike_comment:
            create_like_comment = LikeReplyModel.create(user_id=user_id, post_id=post_id, comment_id=comment_id, reply_id=reply_id)
            await self.like_repo.save(like=create_like_comment)
            comment.reply_like_count = comment.reply_like_count + 1
            await self.like_repo.session.commit()
            return {"message": "Comment Reply Liked"}
        else:
            comment.reply_like_count = comment.reply_like_count - 1
            await self.like_repo.delete(like_unlike_comment)
            await self.like_repo.session.commit()
            return {"message": "Comment Reply Unliked"}








