import datetime
from app.v1.schema import CreateTagRequest
from app.v1.repository import TagRepo, PostRepo
from fastapi import Depends, HTTPException, status
from fastapi_pagination import paginate
from httpx import AsyncClient
from pydantic.schema import UUID
from fastapi.encoders import jsonable_encoder
from pydantic import ValidationError, validator
from core import db_session
import hashlib

from app.v1.models import TagModel, PostModel


class TagCommandService:
    def __init__(self,
                 tag_repo: TagRepo = Depends(TagRepo),
                 ):
        self.tag_repo = tag_repo

    async def create_tag(self, name: str):
        tag = TagModel.create(name=name)
        tag = await self.tag_repo.save(tag)
        await self.tag_repo.session.commit()
        return tag


