from fastapi import Depends, HTTPException
from app.v1.repository import CommentRepo, PostRepo, UserRepo
from app.v1.models import CommentModel, PostModel
import uuid
from uuid import UUID
from app.v1.schema import CreateCommentRequest, CreateCommentResponse
class CommentCommandService:
    def __init__(
            self,
            comment_repo: CommentRepo = Depends(CommentRepo),
            post_repo: PostRepo = Depends(PostRepo),
            user_repo: UserRepo = Depends(UserRepo)
    ):
        self.comment_repo=comment_repo
        self.post_repo=post_repo
        self.user_repo=user_repo
    async def create_comment(
            self,
            comment: list,
            user_id: UUID,
            post_id: UUID,
            reply_id: UUID
    ):
        post = await self.post_repo.get_by_post_id(post_id=post_id)
        if not post:
            raise HTTPException(status_code=409, detail="Post Not Found")
        comment=CommentModel(comment_id=uuid.uuid4(), comment=comment, user_id=user_id, post_id=post_id, reply_id=reply_id)
        comment=await self.comment_repo.save(comment=comment)
        post.comment_count = post.comment_count + 1
        await self.comment_repo.session.commit()
        return comment

    # async def read_comment(self, post_id: UUID):
    #     post = await self.post_repo.get_by_post_id(post_id=post_id)
    #     if not post:
    #         raise HTTPException(status_code=409, detail="Post Not Found")

    async def show_comment_reply(self, comment_id: UUID):
        comment = await self.comment_repo.get_comment_id(comment_id=comment_id)
        if not comment:
            raise HTTPException(status_code=409, detail="Comment Not Found")
        if not comment.comment_reply:
            return {"message": "No one reply on this comment"}
        else:
            return comment.comment_reply

    async def delete_comment(self, comment_id: UUID, post_id: UUID, user_id: UUID):
        post = await self.post_repo.get_by_post_id(post_id=post_id)
        if not post:
            raise HTTPException(status_code=409, detail="Post Not Found")
        else:
            comment = await self.comment_repo.get_comment_post_id(post_id=post_id, comment_id=comment_id)
            if not comment:
                raise HTTPException(status_code=409, detail="Comment Not Found")
            else:
                if comment_id and post_id:
                    if comment.user_id != user_id:
                        raise HTTPException(status_code=409, detail="Can not Delete")
                    else:
                        await self.comment_repo.delete(comment)
        await self.comment_repo.session.commit()
        return {"message": "successfully deleted"}

    async def update_comment(self,post_id: UUID, comment_id: UUID, user_id: UUID, request: CreateCommentRequest):
        post = await self.post_repo.get_by_post_id(post_id=post_id)
        if not post:
            raise HTTPException(status_code=409, detail="Post Not Found")
        else:
            comment = await self.comment_repo.get_comment_post_id(post_id=post_id, comment_id=comment_id)
            if not comment:
                raise HTTPException(status_code=409, detail="Comment Not Found")
            else:
                if comment_id and post_id:
                    if comment.user_id != user_id:
                        raise HTTPException(status_code=409, detail="Can not Update")
                    else:
                        comment.comment = request.comment
                        self.comment_repo.session.add(comment)
        await self.post_repo.session.commit()
        await self.post_repo.session.refresh(comment)
        return comment

    async def reply_comment(self, post_id: UUID, comment_id: UUID, user_id: UUID,  request: CreateCommentRequest):
        user = await self.user_repo.get_by_userid(user_id=user_id)
        if not user:
            raise HTTPException(status_code=409, detail="User Not Found")
        post = await self.post_repo.get_by_post_id(post_id=post_id)
        if not post:
            raise HTTPException(status_code=409, detail="Post Not Found")
        else:
            comment = await self.comment_repo.get_comment_post_id(post_id=post_id, comment_id=comment_id)
            if not comment:
                raise HTTPException(status_code=409, detail="Post - Comment Not Found")
            else:
                comment.comment_reply = request.comment
                comment.reply_id = uuid.uuid4()
                comment.reply_count = comment.reply_count + 1
                self.comment_repo.session.add(comment)
        await self.post_repo.session.commit()
        await self.post_repo.session.refresh(comment)
        return comment



