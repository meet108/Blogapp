import datetime
import uuid

from core.utils.password import Hasher
from app.v1.schema import CreateUserRequestSchema
from app.v1.repository.user_repo import UserRepo
from app.v1.repository.code_repo import CodeRepo
from fastapi import Depends, HTTPException, status, Request
from fastapi_pagination import paginate
from httpx import AsyncClient
from pydantic.schema import UUID
from fastapi.encoders import jsonable_encoder
from pydantic import ValidationError, validator
from core import db_session
from core.utils.jwt_token import JWToken, access, refresh
from jose import jwt
import hashlib
from app.v1.schema.response import LoginUserResponse
from app.v1.models.user_model import UserModel, CodeModel
from random import randint


class UserCommandService:
    def __init__(self,
                 user_repo: UserRepo = Depends(UserRepo),
                 code_repo: CodeRepo = Depends(CodeRepo)
                 ):
        self.user_repo = user_repo
        self.code_repo = code_repo

    async def create_user(self,
                          first_name: str,
                          last_name: str,
                          email: str,
                          password: str
                          ):

        if email and await self.user_repo.get_with_email(email=email):
            raise HTTPException(status_code=409, detail="Email already registered.")
        user = UserModel.create(first_name=first_name, last_name=last_name, email=email, password=password)
        user = await self.user_repo.save(user)
        await self.user_repo.session.commit()
        return user

    async def login_user(self, email: str, password: str):
        user = await self.user_repo.get_with_email(email=email)
        if not user:
            raise HTTPException(status_code=409, detail="User Not Found")
        if password:
            if not Hasher.verify_password(password, user.password):
                raise HTTPException(status_code=409, detail="Incorrect Password.")
        access_token = access.encode(payload={"id": f"{user.user_id}"})
        refresh_token = refresh.encode(payload={"id": f"{user.user_id}"})
        return LoginUserResponse(access_token=access_token, refresh_token=refresh_token)

    async def forgot_password(self, email: str):
        user = await self.user_repo.get_with_email(email=email)
        if not user:
            raise HTTPException(status_code=409, detail="User Not Found")
        code = await self.code_repo.get_with_email(email=email)
        if code:
            new_otp_code = randint(10000,100000)
            code.otp_code = new_otp_code
            code.expired = datetime.datetime.now() + datetime.timedelta(minutes=5)
            return await self.code_repo.update_otp(code)
        code = CodeModel.create_code(email=email)
        code = await self.code_repo.save(code)
        await self.code_repo.session.commit()
        return code

    async def reset_password(self,email: str, otp_code: int, new_password:str, confirm_password: str):
        code_email = await self.code_repo.verify_email_otp(email=email, otp_code=otp_code)
        if not code_email:
            raise HTTPException(status_code=409, detail="Rewrite Mail Or Incorrect Otp")
        code = await self.code_repo.verify_otp(otp_code=otp_code)
        current_time = datetime.datetime.now()
        print(current_time)
        print(code)
        if code:
            if current_time > code.expired:
                raise HTTPException(status_code=409, detail="Otp Expired")
        email=code.email
        print(email)
        user = await self.user_repo.get_with_email(email)
        if new_password != confirm_password:
            raise HTTPException(status_code=409, detail="Password Not Match")
        confirm_password = Hasher.get_password_hash(confirm_password)
        print(confirm_password)
        user.password = confirm_password
        return await self.user_repo.update_password(user)

    async def change_password(self,user_id:UUID, old_password: str, change_password: str, confirm_password: str):
        user = await self.user_repo.get_by_userid(user_id=user_id)
        if old_password:
            if not Hasher.verify_password(old_password, user.password):
                raise HTTPException(status_code=409, detail="Password is not match with your current password.")
        if change_password != confirm_password:
            raise HTTPException(status_code=409, detail="Password Not Match")
        confirm_password = Hasher.get_password_hash(confirm_password)
        print(confirm_password)
        user.password = confirm_password
        return await self.user_repo.update_password(user)

    async def show_user(self):
        result = await self.user_repo.get_all()
        return result

    async def delete_user(self, user_id:UUID):
        user = await self.user_repo.get_by_userid(user_id=user_id)
        await self.user_repo.session.delete(user)
        await self.user_repo.session.commit()
        return {"message":"successfully deleted"}

    async def update_user(self, user_id: UUID, request: CreateUserRequestSchema):
        user = await self.user_repo.get_by_userid(user_id=user_id)
        for var, value in vars(request).items():
            setattr(user, var, value) if value else None
        user.password = Hasher.get_password_hash(user.password)
        self.user_repo.session.add(user)
        await self.user_repo.session.commit()
        await self.user_repo.session.refresh(user)
        return user
