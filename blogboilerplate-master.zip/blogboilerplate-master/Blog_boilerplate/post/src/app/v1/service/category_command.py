import datetime
from app.v1.schema import CreateCategoryRequest
from app.v1.repository.category_repo import CategoryRepo
from fastapi import Depends, HTTPException, status
from fastapi_pagination import paginate
from httpx import AsyncClient
from pydantic.schema import UUID
from fastapi.encoders import jsonable_encoder
from pydantic import ValidationError, validator
from core import db_session
import hashlib

from app.v1.models.category_model import CategoryModel


class CategoryCommandService:
    def __init__(self,
                 category_repo: CategoryRepo = Depends(CategoryRepo)
                 ):
        self.category_repo = category_repo

    async def create_category(self, name: str):
        category = CategoryModel.create(name=name)
        category = await self.category_repo.save(category)
        await self.category_repo.session.commit()
        return category



