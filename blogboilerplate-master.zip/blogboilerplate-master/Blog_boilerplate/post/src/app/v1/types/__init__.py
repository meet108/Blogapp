from enum import Enum


class SupportedFormats(Enum):
    """
    Enum for supported formats.
    """

    # for video
    mp4 = "mp4"
    webm = "webm"
    mkv = "mkv"
    mov = "mov"
    m4v = "m4v"
    # for images
    jpeg = "jpeg"
    jpg = "jpg"
    png = "png"
