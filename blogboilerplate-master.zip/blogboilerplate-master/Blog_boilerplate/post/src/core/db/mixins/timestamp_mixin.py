from sqlalchemy import Column, DateTime, func
from sqlalchemy.ext.declarative import declared_attr

# declared_attr : Mark a class-level method as representing the definition of a mapped property or special
# declarative member name.

class TimestampMixin:
    """
    A Mixin class that can be user in SQLAlchemy db models where resective fields are
    needed.
    """

    @declared_attr
    def created_at(cls):
        """
        Defining a created at column.
        """
        return Column(DateTime, default=func.now(), nullable=False)

    @declared_attr
    def updated_at(cls):
        """
        Defining a updated at column.
        """
        return Column(DateTime, default=func.now(), onupdate=func.now(), nullable=False)

    @declared_attr
    def deleted_at(cls):
        """
        Defining a delete at column.
        """
        return Column(DateTime, nullable=True)
