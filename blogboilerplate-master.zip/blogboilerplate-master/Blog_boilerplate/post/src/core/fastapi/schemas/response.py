from pydantic import BaseModel


class ExceptionResponseSchema(BaseModel):
    """A schema for exceptions raised"""

    message: str


class StatusResponseSchema(BaseModel):
    """A schema for status responses"""

    pass
