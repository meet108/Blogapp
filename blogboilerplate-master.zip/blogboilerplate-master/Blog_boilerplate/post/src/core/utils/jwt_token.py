from datetime import datetime, timedelta
from typing import Any, Dict, Literal
from fastapi.security import HTTPBearer
from fastapi.security.utils import get_authorization_scheme_param
from jwt import encode, decode, DecodeError, ExpiredSignatureError
from starlette.requests import Request
from fastapi import Depends, HTTPException, status
from app.v1.models import UserModel
import uuid

JWT_SECRET_KEY = "09d25e094f"
JWT_ALGORITHM = "HS256"


class JWToken(HTTPBearer):

    def __init__(self, type_: Literal["access", "refresh"], *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.type_ = type_

    def encode(self, payload: dict, expire_period: int = 3600) -> str:

        token = encode(
            payload={
                **payload,
                "type": self.type_,
                "exp": datetime.utcnow() + timedelta(seconds=expire_period),
            },
            key=JWT_SECRET_KEY,
            algorithm=JWT_ALGORITHM,
        )
        return token

    def decode(self, token: str) -> dict:
        try:
            payload = decode(
                jwt=token,
                key=JWT_SECRET_KEY,
                algorithms=[JWT_ALGORITHM],
                option={"verify_signature": True, "verify_exp": True},
            )
            if payload.get("type") != self.type_:
                raise HTTPException(status_code=403, detail="Invalid Token")
            else:
                return payload
        except DecodeError:
            raise HTTPException(status_code=403, detail="Invalid Token")
        except ExpiredSignatureError:
            raise HTTPException(status_code=403, detail="Expired Token")

    async def __call__(self, request: Request) -> Dict[str, Any]:

        authorization: str = request.headers.get("Authorization")
        scheme, credentials = get_authorization_scheme_param(authorization)
        if not (authorization and scheme and credentials):
            if self.auto_error:
                raise HTTPException(status_code=403, detail="No Token Exception")
        if scheme.lower() != "bearer":
            if self.auto_error:
                raise HTTPException(status_code=403, detail="Invalid Token")
        return self.decode(token=credentials)


access = JWToken(type_="access", scheme_name="JWT access token")
refresh = JWToken(type_="refresh", scheme_name="JWT refresh token")
